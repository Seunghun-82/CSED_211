/* ID : sho0927, name : OhSeungHun, number : 20190439 */
#include "cachelab.h"
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

typedef struct
{
	int valid;
	int tag;
	int lru_number;
}cache_block;

typedef struct
{
	cache_block** cache_set;
	int set_number;
	int line_number;
}cache;

void caching(cache* simulator, int access, int offset_bit, int set_bit, size_t* hit_count, size_t* miss_count, size_t* eviction_count);
void update_lru(cache* simulator, int access_set, int line_num);

int main(int argc, char** argv)
{
	size_t hit_count = 0;
	size_t miss_count = 0;
	size_t eviction_count = 0;
	int set_bit = 0;
	int offset_bit = 0;

	cache simulator = {};

	FILE* file;

	for(int option; (option = getopt(argc, argv, "s:E:b:t:")) != -1;)
	{
		switch (option)
		{
			case 's':
				set_bit = atoi(optarg);
				simulator.set_number = 1 << set_bit;
				break;
			case 'E':
				simulator.line_number = atoi(optarg);
				break;
			case 'b':
				offset_bit = atoi(optarg);
				break;
			case 't':
				if (!(file = fopen(optarg, "r")))
				{
					return 1;
				}
				break;
			default:
				return 1;
		}
	}

	if ((set_bit == 0) || (simulator.line_number == 0) || (offset_bit == 0) || !(file))
	{
		return 1;
	}

	simulator.cache_set = malloc(sizeof(cache_block*) * simulator.set_number);
	for(int i = 0; i < simulator.set_number; i++)
	{
		simulator.cache_set[i] = malloc(sizeof(cache_block) * simulator.line_number);
	}

	char i_type;
	int access;

	while(fscanf(file, " %c %x%*c%*d", &i_type, &access) != EOF)
	{
		if (i_type == 'I')
		{

		}
		else
		{
			caching(&simulator, access, offset_bit, set_bit, &hit_count, &miss_count, &eviction_count);

			if('M' == i_type)
			{
				caching(&simulator, access, offset_bit, set_bit, &hit_count, &miss_count, &eviction_count);
			}
		}
	}
    printSummary(hit_count, miss_count, eviction_count);

	fclose(file);
	for(int i = 0; i < simulator.set_number; i++)
	{
		free(simulator.cache_set[i]);
	}
	free(simulator.cache_set);
    return 0;

}

void caching(cache* simulator, int access, int offset_bit, int set_bit, size_t* hit_count, size_t* miss_count, size_t* eviction_count)
{
	int access_set = ((access >> offset_bit) & (0xFFFFFFFF >> (32 - set_bit)));
	int tag = 0xFFFFFFFF & (access >> (offset_bit + set_bit));

	cache_block* present_block = &(simulator->cache_set[access_set][0]);

	for(int i = 0; i < simulator->line_number; i++)
	{
		if (present_block->valid == 1)
		{
			if(present_block->tag == tag)
			{
				(*hit_count)++;
				update_lru(simulator, access_set, i);
				return;
			}
		}
		present_block++;
	}

	(*miss_count)++;
	present_block = &(simulator->cache_set[access_set][0]);

	for(int i = 0; i < simulator->line_number; i++)
	{
		if(present_block->valid == 0)
		{
			present_block->valid = 1;
			present_block->tag = tag;
			update_lru(simulator, access_set, i);
			return;
		}
		present_block++;
	}
	(*eviction_count)++;
	present_block = &(simulator->cache_set[access_set][0]);

	for(int i = 0; i < simulator->line_number; i++)
	{
		if(present_block->lru_number == 0)
		{
			present_block->tag = tag;
			present_block->valid = 1;
			update_lru(simulator, access_set, i);
			return;
		}
		present_block++;
	}

	return;

}

void update_lru(cache* simulator, int access_set, int line_num)
{
	cache_block* present_block = &(simulator->cache_set[access_set][line_num]);
	cache_block* tempt_block = &(simulator->cache_set[access_set][0]);

	for(int i = 0; i < simulator->line_number; i++)
	{
		if (tempt_block->valid == 1)
		{
			if(tempt_block->lru_number > present_block->lru_number)
			{
				(tempt_block->lru_number)--;
			}
		}
		tempt_block++;
	}

	present_block->lru_number = simulator->line_number - 1;

	return;
}
